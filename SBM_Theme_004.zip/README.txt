=== Apex Construction ===
Contributors: yourname
Tags: construction, contractor, building, renovation, portfolio, services, responsive-layout, custom-colors, custom-logo, featured-images, full-width-template, translation-ready, grid-layout
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A professional, SEO-optimized WordPress theme designed specifically for general contractors and construction companies. Features service grids, project portfolios, FAQ sections, and customizable contact info via the Customizer.

== Description ==

Apex Construction is a modern, high-performance WordPress theme tailored for building professionals. Built with clean code and semantic HTML5, it ensures excellent SEO rankings and lightning-fast load times. 

Key Features:
* Auto-creates 'Services' and 'Portfolio' categories on activation for instant setup.
* Integrated Contact Info Customizer to easily edit phone number and address without coding.
* Dynamic Service Grid and Project Portfolio powered by standard WordPress posts.
* Responsive Mobile Menu with accessible toggle button.
* Optimized for Core Web Vitals with lazy loading and deferred scripts.
* Translation ready (.pot file included) and RTL supported.
* Clean, modular CSS using native variables for easy color customization.
* Security hardened with XML-RPC disabled and WP version hidden.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the 'Add New' button.
2. Click Upload and choose this zip file (apex-construction.zip).
3. Click "Install Now" and then activate the theme.
4. Go to Appearance > Customize > Contact Information to set your phone and address.
5. Add posts to the auto-created 'Services' and 'Portfolio' categories to populate the homepage.

== Frequently Asked Questions ==

= Do I need to create categories manually? =
No. The theme automatically creates 'Services' and 'Portfolio' categories upon first activation. Simply assign your posts to these categories and they will appear on the homepage.

= How do I change the contact information in the footer/CTA? =
Navigate to Appearance > Customize > Contact Information. You can update the phone number and business address there, and changes will reflect instantly across the site.

= Is this theme compatible with page builders like Elementor? =
Yes. The theme uses standard WordPress hooks and templates, making it fully compatible with Elementor, Beaver Builder, and Gutenberg blocks.

= Why isn't the mobile menu working? =
Ensure you have assigned a menu to the "Primary Menu (Header)" location under Appearance > Menus. The mobile toggle script requires a populated menu to function correctly.

== Changelog ==

= 1.0.0 =
* Initial release
* Added auto-category creation for Services and Portfolio
* Implemented Contact Info Customizer fields
* Added responsive mobile menu with accessibility attributes
* Included translation-ready .pot file
* Security hardening (XML-RPC disabled, WP version removed)

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* FontAwesome Icons: https://fontawesome.com/ (SIL OFL 1.1 License)
* Google Fonts (Inter + Playfair Display): https://fonts.google.com/ (Open Font License)
* Hero Image: Photo by [Author Name] on Unsplash (Unsplash License)