<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 */

get_header(); 
?>

<main id="primary" class="site-main">

    <!-- ✅ HERO SECTION -->
    <section id="home" class="hero">
        <div class="hero-content">
            <h1><?php bloginfo('name'); ?> | <?php echo get_bloginfo('description'); ?></h1>
            <p>Licensed general contractors delivering premium commercial, residential, and industrial construction projects with precision and integrity.</p>
            <a href="#contact" class="btn-primary">Start Your Project</a>
        </div>
    </section>

    <!-- ✅ SERVICES SECTION (Dynamic from Posts or Static) -->
    <section id="services" class="services">
        <div class="section-title">
            <h2>Our Core <span>Services</span></h2>
            <p>Comprehensive construction solutions tailored to your needs</p>
        </div>
        <div class="service-grid">
            <?php 
            // Query services (Assuming you create a 'Services' category or CPT)
            $services = new WP_Query(array(
                'category_name' => 'services',
                'posts_per_page' => 4,
                'orderby' => 'menu_order'
            ));

            if ($services->have_posts()) : 
                while ($services->have_posts()) : $services->the_post(); 
                    $icon = get_post_meta(get_the_ID(), '_service_icon', true); // Custom field for icon
                    if(!$icon) $icon = 'fas fa-hard-hat'; // Fallback icon
            ?>
                <article class="service-card" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <div class="service-icon"><i class="<?php echo esc_attr($icon); ?>"></i></div>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                </article>
            <?php 
                endwhile; 
                wp_reset_postdata();
            else : 
            ?>
                <!-- Fallback static content if no services are added yet -->
                <article class="service-card">
                    <div class="service-icon"><i class="fas fa-city"></i></div>
                    <h3>Commercial Construction</h3>
                    <p>Office buildings, retail spaces, and mixed-use developments delivered on time.</p>
                </article>
                <article class="service-card">
                    <div class="service-icon"><i class="fas fa-home"></i></div>
                    <h3>Residential Building</h3>
                    <p>Custom homes, multi-family units, and luxury renovations with meticulous detail.</p>
                </article>
                <article class="service-card">
                    <div class="service-icon"><i class="fas fa-industry"></i></div>
                    <h3>Industrial Projects</h3>
                    <p>Warehouses, manufacturing facilities, and infrastructure projects built to last.</p>
                </article>
                <article class="service-card">
                    <div class="service-icon"><i class="fas fa-tools"></i></div>
                    <h3>Renovation & Remodeling</h3>
                    <p>Transform existing structures with modern upgrades while preserving integrity.</p>
                </article>
            <?php endif; ?>
        </div>
    </section>

    <!-- ✅ STATS BAR (Can be made dynamic via ACF/Options Page later) -->
    <section class="stats">
        <div class="stats-grid">
            <div><span class="stat-number">28+</span><span class="stat-label">Years Experience</span></div>
            <div><span class="stat-number">450+</span><span class="stat-label">Projects Completed</span></div>
            <div><span class="stat-number">100%</span><span class="stat-label">Licensed & Insured</span></div>
            <div><span class="stat-number">98%</span><span class="stat-label">Client Satisfaction</span></div>
        </div>
    </section>

    <!-- ✅ PORTFOLIO SECTION (Using Standard Posts with 'portfolio' category) -->
    <section id="portfolio" class="portfolio">
        <div class="section-title">
            <h2>Featured <span>Projects</span></h2>
            <p>Showcasing our commitment to quality and innovation</p>
        </div>
        <div class="portfolio-grid">
            <?php 
            $projects = new WP_Query(array(
                'category_name' => 'portfolio',
                'posts_per_page' => 3
            ));

            if ($projects->have_posts()) : 
                while ($projects->have_posts()) : $projects->the_post(); 
                    $thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
                    if(!$thumbnail_url) $thumbnail_url = 'https://via.placeholder.com/800x600/1e3a8a/ffffff?text=Project+Image';
            ?>
                <div class="project-card">
                    <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                    <div class="project-overlay">
                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <p><?php echo wp_trim_words(get_the_excerpt(), 10, ''); ?></p>
                    </div>
                </div>
            <?php 
                endwhile; 
                wp_reset_postdata();
            endif; 
            ?>
        </div>
    </section>

    <!-- ✅ FAQ SECTION (Using a custom query or plugin shortcode recommended) -->
    <section id="faq" class="faq">
        <div class="section-title">
            <h2>Frequently Asked <span>Questions</span></h2>
        </div>
        <?php 
        // Option 1: Use a FAQ Plugin Shortcode (Recommended for clients)
        // echo do_shortcode('[faq_shortcode]'); 
        
        // Option 2: Static fallback matching original HTML
        ?>
        <div class="faq-item active">
            <div class="faq-question" onclick="this.parentElement.classList.toggle('active')">
                Are you fully licensed and insured? <i class="fas fa-chevron-down"></i>
            </div>
            <div class="faq-answer">
                Yes, Apex Construction holds all required state contractor licenses and carries comprehensive general liability and workers' compensation insurance.
            </div>
        </div>
        <div class="faq-item">
            <div class="faq-question" onclick="this.parentElement.classList.toggle('active')">
                What is your typical project timeline? <i class="fas fa-chevron-down"></i>
            </div>
            <div class="faq-answer">
                Timelines vary by scope. A custom home typically takes 8-12 months, while commercial projects range from 6-18 months.
            </div>
        </div>
    </section>

    <!-- ✅ CONTACT CTA -->
    <section id="contact" class="contact-cta">
        <h2>Ready to Build Your Vision?</h2>
        <p>Contact us today for a free consultation and project estimate</p>
        <div class="contact-info">
            <div class="contact-item"><i class="fas fa-phone"></i> <?php echo get_option('phone_number', '(555) 123-4567'); ?></div>
            <div class="contact-item"><i class="fas fa-envelope"></i> <?php echo get_option('admin_email'); ?></div>
            <div class="contact-item"><i class="fas fa-map-marker-alt"></i> <?php echo get_option('business_address', '123 Builder Ave, Los Angeles, CA'); ?></div>
        </div>
        <a href="mailto:<?php echo get_option('admin_email'); ?>" class="btn-primary">Request Free Quote</a>
    </section>

</main><!-- #main -->

<?php
get_sidebar();
get_footer();
?>