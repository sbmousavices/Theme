<?php
/**
 * Apex Construction Theme Functions and Definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 */

if ( ! defined( 'APEX_VERSION' ) ) {
    define( 'APEX_VERSION', '1.0.0' );
}

/**
 * ✅ 1. SETUP THEME SUPPORT & FEATURES
 */
function apex_setup() {
    // Translation support
    load_theme_textdomain( 'apex', get_template_directory() . '/languages' );

    // Default post thumbnails and custom logos
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 800, 600, true ); // Crop for portfolio cards
    
    // Title tag management
    add_theme_support( 'title-tag' );
    
    // HTML5 markup for search forms, comment forms, etc.
    add_theme_support( 'html5', array( 
        'search-form', 
        'comment-form', 
        'comment-list', 
        'gallery', 
        'caption', 
        'style', 
        'script' 
    ) );

    // Custom Logo support
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-width'  => true,
        'flex-height' => true,
    ) );
}
add_action( 'after_setup_theme', 'apex_setup' );

/**
 * ✅ 2. ENQUEUE STYLES & SCRIPTS
 */
function apex_scripts() {
    // Main stylesheet
    wp_enqueue_style( 'apex-style', get_stylesheet_uri(), array(), APEX_VERSION );
    
    // Google Fonts (Inter + Playfair Display)
    wp_enqueue_style( 'apex-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap', array(), null );
    
    // FontAwesome Icons
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
    
    // Mobile Menu Toggle Script
    wp_enqueue_script( 
        'apex-mobile-menu', 
        get_template_directory_uri() . '/assets/js/mobile-menu.js', 
        array(), 
        APEX_VERSION, 
        true 
    );
}
add_action( 'wp_enqueue_scripts', 'apex_scripts' );

/**
 * ✅ 3. REGISTER NAVIGATION MENUS
 */
function apex_register_menus() {
    register_nav_menus( array(
        'primary'   => __( 'Primary Menu (Header)', 'apex' ),
        'footer'    => __( 'Footer Menu', 'apex' ),
    ) );
}
add_action( 'init', 'apex_register_menus' );

/**
 * ✅ 4. REGISTER WIDGET AREAS (SIDEBARS)
 */
function apex_widgets_init() {
    // Footer Widget Area (4 columns)
    register_sidebar( array(
        'name'          => __( 'Footer Widgets', 'apex' ),
        'id'            => 'footer-widgets',
        'description'   => __( 'Add widgets here for the footer section.', 'apex' ),
        'before_widget' => '<div class="footer-col"><div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h4>',
        'after_title'   => '</h4>',
    ) );
}
add_action( 'widgets_init', 'apex_widgets_init' );

/**
 * ✅ 5. CUSTOM EXCERPT LENGTH FOR SERVICES
 */
function apex_custom_excerpt_length( $length ) {
    return 20; // Shorter excerpts for service cards
}
add_filter( 'excerpt_length', 'apex_custom_excerpt_length', 999 );

/**
 * ✅ 6. ADD CUSTOM FIELDS FOR CONTACT INFO IN CUSTOMIZER
 */
function apex_customize_register( $wp_customize ) {
    // Contact Info Section
    $wp_customize->add_section( 'apex_contact_info', array(
        'title'    => __( 'Contact Information', 'apex' ),
        'priority' => 30,
    ) );

    // Phone Number
    $wp_customize->add_setting( 'phone_number', array(
        'default'           => '(555) 123-4567',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'phone_number', array(
        'label'   => __( 'Phone Number', 'apex' ),
        'section' => 'apex_contact_info',
        'type'    => 'text',
    ) );

    // Business Address
    $wp_customize->add_setting( 'business_address', array(
        'default'           => '123 Builder Ave, Los Angeles, CA',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'business_address', array(
        'label'   => __( 'Business Address', 'apex' ),
        'section' => 'apex_contact_info',
        'type'    => 'text',
    ) );
}
add_action( 'customize_register', 'apex_customize_register' );

/**
 * ✅ 7. AUTO-CREATE REQUIRED CATEGORIES ON THEME ACTIVATION
 */
function apex_create_default_categories() {
    $categories = array(
        'services'  => 'Services',
        'portfolio' => 'Portfolio',
    );

    foreach ( $categories as $slug => $name ) {
        if ( ! term_exists( $slug, 'category' ) ) {
            wp_insert_term( $name, 'category', array( 'slug' => $slug ) );
        }
    }
}
add_action( 'after_switch_theme', 'apex_create_default_categories' );

/**
 * ✅ 8. SECURITY & PERFORMANCE TWEAKS
 */
// Remove WP version from head
remove_action( 'wp_head', 'wp_generator' );

// Disable XML-RPC (Security)
add_filter( 'xmlrpc_enabled', '__return_false' );

// Add async/defer to scripts where possible
function apex_defer_scripts( $tag, $handle, $src ) {
    if ( in_array( $handle, array( 'jquery', 'jquery-core', 'jquery-migrate' ), true ) ) {
        return $tag; // Don't defer jQuery
    }
    return str_replace( ' src', ' defer src', $tag );
}
add_filter( 'script_loader_tag', 'apex_defer_scripts', 10, 3 );