=== SBM Theme 002 - Futuristic Glassmorphism Portfolio ===
Contributors: Behzad Mousavi
Tags: portfolio, dark-mode, glassmorphism, neon, responsive, one-column, custom-colors, translation-ready
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A next-generation glassmorphism portfolio theme with neon accents and smooth animations. Perfect for creatives, developers, and digital artists looking to captivate their audience.

== Description ==

SBM Theme 002 is a cutting-edge WordPress theme designed to push the boundaries of modern web aesthetics. Featuring a futuristic glassmorphism UI, fluid CSS animations, and a deep dark mode canvas with vibrant neon gradients, this theme ensures your portfolio stands out in the digital horizon.

Key Features:
*   **Futuristic Glassmorphism Design:** Modern frosted glass cards and navigation that adapt beautifully to any content.
*   **Neon & Dark Mode Aesthetics:** Carefully crafted color palette using cyan and purple neon accents against a deep black background.
*   **Fluid CSS Animations:** Smooth hover effects, glowing buttons, and an animated background mesh without heavy JavaScript dependencies.
*   **Fully Responsive:** Seamless experience across desktops, tablets, and mobile devices with fluid typography.
*   **SEO Optimized:** Clean HTML5 structure, dynamic title tags, and minimal code bloat for maximum search engine visibility.
*   **Performance Focused:** Zero external framework dependencies; pure CSS animations ensure lightning-fast load times.
*   **Translation Ready:** Built with standard WordPress i18n functions, making it easy to translate into any language.
*   **Customizable Contact Section:** Pre-designed glass cards for email, phone, location, and social media integration.

== Installation ==

1.  In your WordPress admin panel, go to Appearance > Themes.
2.  Click "Add New" and then "Upload Theme".
3.  Choose the `sbm-theme-002.zip` file and click "Install Now".
4.  Once installed, click "Activate".
5.  Go to Appearance > Menus to create and assign your Primary Menu.
6.  Visit Appearance > Customize to adjust site identity and colors if needed.

== Frequently Asked Questions ==

= Does this theme support page builders? =
Yes! SBM Theme 002 is fully compatible with popular page builders like Elementor, Gutenberg, and Beaver Builder. The glassmorphism styles are built on top of standard WordPress classes, so they won't conflict with your builder's layout.

= How do I change the neon colors? =
The theme uses CSS variables for easy customization. You can override the `--neon-primary` and `--neon-secondary` variables in the Additional CSS section under Appearance > Customize.

= Is this theme RTL (Right-to-Left) ready? =
Absolutely. The theme is built with internationalization standards and supports RTL languages natively.

== Changelog ==

= 1.0.0 =
*   Initial release of SBM Theme 002.
*   Added glassmorphism UI components and neon accent system.
*   Implemented animated background mesh using pure CSS.
*   Added responsive contact section with social media integration.
*   Optimized for performance and SEO.

== Credits ==

*   Based on Underscores https://underscores.me/, (C) 2012-2024 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
*   Font Awesome Icons: https://fontawesome.com/ (SIL OFL 1.1 License)
*   Google Fonts: Space Grotesk & Outfit (OFL License)
*   Designed and Developed by Behzad Mousavi

== Copyright ==

SBM Theme 002 WordPress Theme, (C) 2026 Behzad Mousavi
SBM Theme 002 is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.