<?php
// ==========================================
// SBM THEME 002 - CONFIGURATION
// ==========================================
$site_title = "SBM Theme 002 | Futuristic Portfolio Template";
$site_description = "A next-gen glassmorphism portfolio theme with neon accents and smooth animations.";
$author_name = "Behzad Mousavi";
$contact_email = "sbmousavi@proton.me";
$current_year = date("Y");
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $site_title; ?></title>
    <meta name="description" content="<?php echo $site_description; ?>">
    <meta name="author" content="<?php echo $author_name; ?>">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;500;700&family=Outfit:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        :root {
            --bg-dark: #050505;
            --glass-bg: rgba(255, 255, 255, 0.03);
            --glass-border: rgba(255, 255, 255, 0.08);
            --neon-primary: #00f2ff;
            --neon-secondary: #bc13fe;
            --text-main: #ffffff;
            --text-muted: #a0a0a0;
            --font-display: 'Space Grotesk', sans-serif;
            --font-body: 'Outfit', sans-serif;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            background-color: var(--bg-dark);
            color: var(--text-main);
            font-family: var(--font-body);
            overflow-x: hidden;
            line-height: 1.6;
        }

        /* Animated Background Mesh */
        .bg-mesh {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            z-index: -1;
            background: 
                radial-gradient(circle at 15% 50%, rgba(188, 19, 254, 0.15), transparent 40%),
                radial-gradient(circle at 85% 30%, rgba(0, 242, 255, 0.15), transparent 40%);
            filter: blur(60px);
            animation: meshMove 20s infinite alternate ease-in-out;
        }

        @keyframes meshMove {
            0% { transform: scale(1); }
            100% { transform: scale(1.2); }
        }

        /* Navigation */
        nav {
            position: fixed;
            top: 2rem;
            left: 50%;
            transform: translateX(-50%);
            width: 90%;
            max-width: 1000px;
            padding: 1rem 2rem;
            background: rgba(10, 10, 10, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 100px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .logo {
            font-family: var(--font-display);
            font-weight: 700;
            font-size: 1.5rem;
            letter-spacing: -1px;
            background: linear-gradient(to right, var(--neon-primary), var(--neon-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-links { display: flex; gap: 2rem; list-style: none; }
        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
            font-size: 0.95rem;
        }
        .nav-links a:hover { color: var(--text-main); }

        /* Hero Section */
        .hero {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 0 5%;
            position: relative;
        }

        .hero h1 {
            font-family: var(--font-display);
            font-size: clamp(3rem, 8vw, 7rem);
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            letter-spacing: -2px;
        }

        .hero h1 span {
            display: block;
            background: linear-gradient(135deg, #fff 0%, #a0a0a0 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero p {
            font-size: 1.2rem;
            color: var(--text-muted);
            max-width: 600px;
            margin-bottom: 3rem;
        }

        .btn-glow {
            padding: 1rem 2.5rem;
            background: transparent;
            border: 1px solid var(--neon-primary);
            color: var(--neon-primary);
            font-family: var(--font-display);
            font-weight: 600;
            font-size: 1rem;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
        }

        .btn-glow:hover {
            background: var(--neon-primary);
            color: #000;
            box-shadow: 0 0 30px rgba(0, 242, 255, 0.4);
        }

        /* Features Grid */
        .features {
            max-width: 1200px;
            margin: 0 auto;
            padding: 5rem 5%;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .glass-card {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 24px;
            padding: 2.5rem;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
        }

        .glass-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.05), transparent);
            transform: translateX(-100%);
            transition: 0.6s;
        }

        .glass-card:hover {
            transform: translateY(-10px);
            border-color: rgba(255, 255, 255, 0.2);
            box-shadow: 0 20px 40px rgba(0,0,0,0.4);
        }

        .glass-card:hover::before { transform: translateX(100%); }

        .card-icon {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
            background: linear-gradient(to bottom right, var(--neon-primary), var(--neon-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .glass-card h3 {
            font-family: var(--font-display);
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }

        .glass-card p { color: var(--text-muted); font-size: 0.95rem; }

        /* ✅ CONTACT SECTION STYLES */
        .contact-section {
            max-width: 800px;
            margin: 0 auto;
            padding: 5rem 5%;
            text-align: center;
        }

        .contact-title {
            font-family: var(--font-display);
            font-size: 2.5rem;
            margin-bottom: 1rem;
            background: linear-gradient(to right, var(--neon-primary), var(--neon-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .contact-subtitle {
            color: var(--text-muted);
            margin-bottom: 3rem;
            font-size: 1.1rem;
        }

        .contact-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 3rem;
        }

        .contact-item {
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 1.5rem;
            text-decoration: none;
            color: var(--text-main);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.8rem;
        }

        .contact-item:hover {
            border-color: var(--neon-primary);
            box-shadow: 0 0 20px rgba(0, 242, 255, 0.15);
            transform: translateY(-5px);
        }

        .contact-item i {
            font-size: 1.8rem;
            color: var(--neon-primary);
        }

        .contact-item span {
            font-size: 0.9rem;
            font-weight: 500;
        }

        .social-icons {
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .social-link {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--glass-bg);
            border: 1px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-muted);
            font-size: 1.2rem;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .social-link:hover {
            color: var(--neon-secondary);
            border-color: var(--neon-secondary);
            box-shadow: 0 0 20px rgba(188, 19, 254, 0.3);
            transform: translateY(-3px);
        }

        /* ✅ FOOTER STYLES */
        footer {
            margin-top: 5rem;
            padding: 2rem 5%;
            border-top: 1px solid var(--glass-border);
            text-align: center;
            color: var(--text-muted);
            font-size: 0.9rem;
            background: rgba(0, 0, 0, 0.3);
        }

        /* Responsive */
        @media (max-width: 768px) {
            nav { width: 95%; padding: 0.8rem 1.5rem; top: 1rem; }
            .nav-links { display: none; }
            .hero h1 { font-size: 3.5rem; }
            .contact-title { font-size: 2rem; }
        }
    </style>
</head>
<body>
    <div class="bg-mesh"></div>

    <nav>
        <div class="logo">SBM.002</div>
        <ul class="nav-links">
            <li><a href="#">Features</a></li>
            <li><a href="#">Showcase</a></li>
            <li><a href="#">Docs</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </nav>

    <section class="hero">
        <h1>
            <span>Beyond The</span>
            <span style="background: linear-gradient(to right, var(--neon-primary), var(--neon-secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Digital Horizon</span>
        </h1>
        <p>A next-generation glassmorphism template designed to captivate your audience with fluid animations and neon aesthetics.</p>
        <button class="btn-glow">Explore The Future</button>
    </section>

    <section class="features">
        <div class="glass-card">
            <i class="fas fa-bolt card-icon"></i>
            <h3>Lightning Fast</h3>
            <p>Optimized for performance with zero external dependencies and pure CSS animations.</p>
        </div>
        <div class="glass-card">
            <i class="fas fa-layer-group card-icon"></i>
            <h3>Glassmorphism UI</h3>
            <p>Modern frosted glass effects that adapt beautifully to any background or color scheme.</p>
        </div>
        <div class="glass-card">
            <i class="fas fa-mobile-alt card-icon"></i>
            <h3>Fully Responsive</h3>
            <p>Seamless experience across all devices with fluid typography and adaptive layouts.</p>
        </div>
    </section>

    <!-- ✅ CONTACT SECTION ADDED HERE -->
    <section id="contact" class="contact-section">
        <h2 class="contact-title">Let's Create Together</h2>
        <p class="contact-subtitle">Ready to bring your vision to life? Reach out directly or connect on social platforms.</p>
        
        <div class="contact-grid">
            <a href="mailto:<?php echo $contact_email; ?>" class="contact-item">
                <i class="fas fa-envelope"></i>
                <span>Email Me Directly</span>
            </a>
            <a href="tel:+989123456789" class="contact-item">
                <i class="fas fa-phone"></i>
                <span>Call / WhatsApp</span>
            </a>
            <a href="#" class="contact-item">
                <i class="fas fa-map-marker-alt"></i>
                <span>Your Location</span>
            </a>
        </div>

        <div class="social-icons">
            <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
            <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
            <a href="#" class="social-link"><i class="fab fa-github"></i></a>
            <a href="#" class="social-link"><i class="fab fa-telegram-plane"></i></a>
        </div>
    </section>

    <!-- ✅ FOOTER WITH DIVIDER LINE -->
    <footer>
        <p>&copy; <?php echo $current_year; ?> <?php echo $author_name; ?>. All Rights Reserved. | Professional Digital Solutions</p>
    </footer>
</body>
</html>