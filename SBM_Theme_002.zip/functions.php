<?php
/**
 * SBM Theme 002 Functions and Definitions
 * 
 * @package SBM_Theme_002
 * @author Behzad Mousavi
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // جلوگیری از دسترسی مستقیم
}

// ==========================================
// 1. SETUP THEME FEATURES
// ==========================================
function sbm_theme_setup() {
    // پشتیبانی از عنوان دینامیک (سئو)
    add_theme_support('title-tag');
    
    // پشتیبانی از تصویر شاخص (Featured Image)
    add_theme_support('post-thumbnails');
    
    // تبدیل تصاویر به HTML5 استاندارد
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    // ثبت منوی اصلی
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'sbm-theme-002'),
    ));
}
add_action('after_setup_theme', 'sbm_theme_setup');

// ==========================================
// 2. ENQUEUE STYLES & SCRIPTS
// ==========================================
function sbm_enqueue_assets() {
    // بارگذاری style.css اصلی
    wp_enqueue_style(
        'sbm-main-style',
        get_stylesheet_uri(),
        array(),
        filemtime(get_stylesheet_directory() . '/style.css') // کش‌شکنی خودکار هنگام تغییر فایل
    );

    // اگر در آینده فایل JS اضافه کردید، اینجا بارگذاری شود
    // wp_enqueue_script('sbm-scripts', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'sbm_enqueue_assets');

// ==========================================
// 3. CLEAN UP WORDPRESS HEAD (Performance)
// ==========================================
// حذف کدهای اضافی که برای تم‌های مدرن و نئونی لازم نیستند
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');

// ==========================================
// 4. CUSTOM EXCERPT LENGTH
// ==========================================
function sbm_custom_excerpt_length($length) {
    return 25; // تعداد کلمات خلاصه مطلب
}
add_filter('excerpt_length', 'sbm_custom_excerpt_length', 999);

// ==========================================
// 5. WIDGET AREAS (Optional for Future)
// ==========================================
function sbm_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widgets', 'sbm-theme-002'),
        'id'            => 'footer-widgets',
        'description'   => __('Add widgets here to appear in your footer.', 'sbm-theme-002'),
        'before_widget' => '<div class="glass-card widget-item">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'sbm_widgets_init');