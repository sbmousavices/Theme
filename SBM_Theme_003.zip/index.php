<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 */

get_header(); 
?>

<main id="primary" class="site-main">

    <!-- ✅ HERO SECTION -->
    <section class="hero">
        <div class="hero-content">
            <h1>Upgrade Your Home with <br><span style="color: var(--accent);">Smart Technology</span></h1>
            <p>Experience the future of living with our premium collection of energy-efficient and AI-powered appliances.</p>
            <a href="#shop" class="btn-hero">Shop Now</a>
        </div>
    </section>

    <!-- ✅ FEATURES STRIP PLUGIN -->
    <div class="features-strip">
        <div class="feature-item">
            <i class="fas fa-shipping-fast"></i>
            <div class="feature-text">
                <h4>Fast Delivery</h4>
                <p>Within 2-3 business days</p>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-shield-alt"></i>
            <div class="feature-text">
                <h4>2 Year Warranty</h4>
                <p>On all major appliances</p>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-undo"></i>
            <div class="feature-text">
                <h4>Easy Returns</h4>
                <p>30-day money back guarantee</p>
            </div>
        </div>
        <div class="feature-item">
            <i class="fas fa-headset"></i>
            <div class="feature-text">
                <h4>Expert Support</h4>
                <p>Dedicated technical team</p>
            </div>
        </div>
    </div>

    <!-- ✅ PRODUCTS GRID (THE LOOP) -->
    <section id="shop" class="products-section">
        <div class="section-title">
            <h2>Trending <span>Appliances</span></h2>
            <p>Top-rated products chosen by our customers this week</p>
        </div>

        <div class="product-grid">
            <?php 
            // Check if there are any posts/products
            if ( have_posts() ) : 
                
                // Start the Loop
                while ( have_posts() ) : the_post(); 
                    
                    // Get product price (WooCommerce compatible) or fallback
                    $price = get_post_meta( get_the_ID(), '_regular_price', true );
                    $sale_price = get_post_meta( get_the_ID(), '_sale_price', true );
                    $thumbnail_url = get_the_post_thumbnail_url( get_the_ID(), 'medium' );
                    
                    // Fallback image if no thumbnail
                    if( !$thumbnail_url ) {
                        $thumbnail_url = 'https://via.placeholder.com/300x300/f1f5f9/64748b?text=No+Image';
                    }
            ?>
            
                <article class="product-card" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    
                    <?php if( $sale_price && $sale_price < $price ) : ?>
                        <span class="product-badge">
                            -<?php echo round((($price - $sale_price) / $price) * 100); ?>%
                        </span>
                    <?php endif; ?>

                    <div class="product-img">
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php the_title_attribute(); ?>">
                        </a>
                    </div>
                    
                    <div class="product-info">
                        <span class="category"><?php echo get_the_category_list(', '); ?></span>
                        <h3 class="product-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        
                        <div class="rating">
                            <!-- You can replace this with actual review plugin shortcode later -->
                            <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half-alt"></i>
                        </div>
                        
                        <div class="price-row">
                            <div>
                                <?php if( $sale_price ) : ?>
                                    <span class="price">$<?php echo number_format($sale_price); ?></span>
                                    <span class="old-price">$<?php echo number_format($price); ?></span>
                                <?php else : ?>
                                    <span class="price">$<?php echo number_format($price ? $price : '0'); ?></span>
                                <?php endif; ?>
                            </div>
                            <a href="<?php the_permalink(); ?>" class="btn-add"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </article>

            <?php 
                endwhile; 
                
                // Pagination
                the_posts_pagination( array(
                    'mid_size'  => 2,
                    'prev_text' => __( '<i class="fas fa-chevron-left"></i>', 'homelux' ),
                    'next_text' => __( '<i class="fas fa-chevron-right"></i>', 'homelux' ),
                ) );
                
            else : 
            ?>
                <p>No appliances found matching your criteria.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- ✅ COUNTDOWN TIMER PLUGIN -->
    <section class="offer-banner">
        <h2>Flash Sale Ends In:</h2>
        <p>Get up to 50% off on selected kitchen gadgets</p>
        <div class="timer" id="countdown">
            <div class="time-box"><span id="days">02</span><label>Days</label></div>
            <div class="time-box"><span id="hours">14</span><label>Hours</label></div>
            <div class="time-box"><span id="minutes">45</span><label>Mins</label></div>
            <div class="time-box"><span id="seconds">12</span><label>Secs</label></div>
        </div>
        <a href="/shop/?orderby=sale" class="btn-hero" style="background: var(--accent);">View Offers</a>
    </section>

</main><!-- #main -->

<?php
get_sidebar();
get_footer();
?>