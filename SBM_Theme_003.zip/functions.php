<?php
/**
 * HomeLux Theme Functions and Definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 */

if ( ! defined( 'HOMELUX_VERSION' ) ) {
    define( 'HOMELUX_VERSION', '1.0.0' );
}

/**
 * ✅ 1. SETUP THEME SUPPORT & FEATURES
 */
function homelux_setup() {
    // Translation support
    load_theme_textdomain( 'homelux', get_template_directory() . '/languages' );

    // Default post thumbnails and custom logos
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 300, 300, true ); // Crop for product cards
    
    // Title tag management
    add_theme_support( 'title-tag' );
    
    // HTML5 markup for search forms, comment forms, etc.
    add_theme_support( 'html5', array( 
        'search-form', 
        'comment-form', 
        'comment-list', 
        'gallery', 
        'caption', 
        'style', 
        'script' 
    ) );

    // WooCommerce Support (CRITICAL for appliance store)
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    // Custom Logo support
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-width'  => true,
        'flex-height' => true,
    ) );
}
add_action( 'after_setup_theme', 'homelux_setup' );

/**
 * ✅ 2. ENQUEUE STYLES & SCRIPTS
 */
function homelux_scripts() {
    // Main stylesheet
    wp_enqueue_style( 'homelux-style', get_stylesheet_uri(), array(), HOMELUX_VERSION );
    
    // Google Fonts (Poppins)
    wp_enqueue_style( 'homelux-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap', array(), null );
    
    // FontAwesome Icons
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
    
    // Countdown Timer Script (Only on front page)
    if ( is_front_page() ) {
        wp_enqueue_script( 
            'homelux-countdown', 
            get_template_directory_uri() . '/assets/js/countdown.js', 
            array(), 
            HOMELUX_VERSION, 
            true 
        );
    }
}
add_action( 'wp_enqueue_scripts', 'homelux_scripts' );

/**
 * ✅ 3. REGISTER NAVIGATION MENUS
 */
function homelux_register_menus() {
    register_nav_menus( array(
        'primary'   => __( 'Primary Menu (Header)', 'homelux' ),
        'footer'    => __( 'Footer Menu', 'homelux' ),
        'mobile'    => __( 'Mobile Menu', 'homelux' ),
    ) );
}
add_action( 'init', 'homelux_register_menus' );

/**
 * ✅ 4. REGISTER WIDGET AREAS (SIDEBARS)
 */
function homelux_widgets_init() {
    // Main Sidebar
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'homelux' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'homelux' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    // Footer Widget Area (4 columns)
    register_sidebar( array(
        'name'          => __( 'Footer Widgets', 'homelux' ),
        'id'            => 'footer-widgets',
        'description'   => __( 'Add widgets here for the footer section.', 'homelux' ),
        'before_widget' => '<div class="footer-col"><div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'homelux_widgets_init' );

/**
 * ✅ 5. CUSTOM EXCERPT LENGTH FOR PRODUCTS
 */
function homelux_custom_excerpt_length( $length ) {
    return 20; // Shorter excerpts for product cards
}
add_filter( 'excerpt_length', 'homelux_custom_excerpt_length', 999 );

/**
 * ✅ 6. ADD "ADD TO CART" BUTTON AFTER SHOP LOOP ITEM TITLE
 * (Enhances UX for appliance shoppers)
 */
add_action( 'woocommerce_after_shop_loop_item_title', 'homelux_add_cart_button', 10 );
function homelux_add_cart_button() {
    global $product;
    echo '<a href="' . esc_url( $product->add_to_cart_url() ) . '" class="btn-add ajax_add_to_cart">';
    echo '<i class="fas fa-shopping-cart"></i> ' . esc_html( $product->add_to_cart_text() );
    echo '</a>';
}

/**
 * ✅ 7. REMOVE DEFAULT WOOCOMMERCE STYLES (Optional - Use your own)
 * Uncomment below if you want full control over styling
 */
// add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/**
 * ✅ 8. SECURITY & PERFORMANCE TWEAKS
 */
// Remove WP version from head
remove_action( 'wp_head', 'wp_generator' );

// Disable XML-RPC (Security)
add_filter( 'xmlrpc_enabled', '__return_false' );

// Add async/defer to scripts where possible
function homelux_defer_scripts( $tag, $handle, $src ) {
    if ( 'jquery' === $handle ) {
        return $tag; // Don't defer jQuery
    }
    return str_replace( ' src', ' defer src', $tag );
}
add_filter( 'script_loader_tag', 'homelux_defer_scripts', 10, 3 );