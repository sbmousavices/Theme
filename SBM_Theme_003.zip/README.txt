=== HomeLux Appliances ===
Contributors: behzadmousavi
Tags: e-commerce, woocommerce, responsive-layout, custom-colors, custom-logo, featured-images, full-width-template, translation-ready, grid-layout, sticky-post
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A premium, SEO-optimized WooCommerce theme designed specifically for home appliances and smart living stores. Features countdown timers, product badges, and responsive layouts.

== Description ==

HomeLux is a modern, high-performance WordPress theme tailored for online appliance retailers. Built with clean code and semantic HTML5, it ensures excellent SEO rankings and lightning-fast load times. 

Key Features:
* Fully compatible with WooCommerce and its gallery extensions (Zoom, Lightbox, Slider).
* Integrated Countdown Timer plugin for flash sales and limited-time offers.
* Dynamic Product Badges (Sale %, New) automatically calculated from pricing data.
* Responsive Feature Strip highlighting delivery, warranty, and support benefits.
* Customizable Header with live search bar and AJAX cart counter.
* Optimized for mobile devices with touch-friendly navigation and grids.
* Translation ready (.pot file included) and RTL supported.
* Clean, modular CSS using native variables for easy color customization.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the 'Add New' button.
2. Click Upload and choose this zip file (homelux.zip).
3. Click "Install Now" and then activate the theme.
4. Go to Appearance > Customize to configure colors, logo, and menus.
5. Install and activate WooCommerce to enable shop functionality.

== Frequently Asked Questions ==

= Does this theme require WooCommerce? =
Yes, HomeLux is designed as an e-commerce theme. While it will function without WooCommerce, the product grids, cart icons, and sale badges are specifically built to work with it.

= How do I change the countdown timer date? =
The countdown timer script is located in /assets/js/countdown.js. You can modify the target date directly in that file, or use a WordPress hook in your child theme's functions.php to make it dynamic via the admin panel.

= Is this theme compatible with page builders like Elementor? =
Yes. The theme uses standard WordPress hooks and templates, making it fully compatible with Elementor, Beaver Builder, and Gutenberg blocks.

== Changelog ==

= 1.0.0 =
* Initial release
* Added WooCommerce support with gallery zoom/lightbox
* Implemented countdown timer plugin
* Added responsive feature strip and product badges
* Included translation-ready .pot file

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* FontAwesome Icons: https://fontawesome.com/ (SIL OFL 1.1 License)
* Google Fonts (Poppins): https://fonts.google.com/specimen/Poppins (Open Font License)
* Hero Image: Photo by [Author Name] on Unsplash (Unsplash License)