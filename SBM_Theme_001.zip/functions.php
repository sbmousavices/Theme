<?php
function behzad_portfolio_setup() {
    // پشتیبانی از تایتل داینامیک وردپرس
    add_theme_support('title-tag');
    
    // ثبت منوی اصلی
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'behzad-portfolio'),
    ));
}
add_action('after_setup_theme', 'behzad_portfolio_setup');

function behzad_portfolio_scripts() {
    // لود کردن فونت‌ها و آیکون‌ها
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Playfair+Display:wght@700;900&display=swap');
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css');
}
add_action('wp_enqueue_scripts', 'behzad_portfolio_scripts');
?>