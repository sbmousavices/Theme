# SBM Theme 001 - Professional Portfolio Theme

A modern, dark-mode portfolio theme designed by Behzad Mousavi.

## Features
- Fully Responsive Design
- Dark Mode with Gold Accents
- SEO Optimized Structure
- Custom Services Section

## How to Install
1. Go to Appearance > Themes > Add New > Upload Theme in your WordPress Dashboard.
2. Select the SBM_Theme_001.zip file and click "Install Now".
3. Activate the theme.
4. Go to Appearance > Menus and create a menu with links like #home, #about, etc.

## Need Customization or SEO?
If you need help setting up this theme or want a custom website design, contact me:
📧 Email: sbmousavi@proton.me
🌐 Portfolio: [Your Website URL]

Thank you for downloading!
- Behzad Mousavi