<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

    <div class="bg-shapes"></div>
    
    <!-- Navigation -->
    <nav>
        <div class="nav-container">
            <div class="logo"><?php bloginfo('name'); ?></div>
            <button class="menu-toggle" aria-label="Menu"><i class="fas fa-bars"></i></button>
            <?php 
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'nav-links',
            )); 
            ?>
        </div>
    </nav>
    
    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="hero-content">
            <div class="hero-text">
                <p class="greeting">Hello, I am</p>
                <h1><?php bloginfo('name'); ?></h1>
                <p class="tagline">Full-stack Developer | UI/UX Designer | Tech Specialist</p>
                <div class="hero-buttons">
                    <a href="#contact" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Contact Me</a>
                    <a href="#projects" class="btn btn-outline"><i class="fas fa-briefcase"></i> View Portfolio</a>
                </div>
            </div>
            <div class="hero-image">
                <div class="avatar-wrapper">
                    <div class="avatar"><i class="fas fa-user"></i></div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section (Static for now, can be made dynamic later) -->
    <section id="about">
        <div class="container">
            <div class="section-header reveal">
                <p class="section-subtitle">About Me</p>
                <h2 class="section-title">Brief <span>Introduction</span></h2>
                <div class="section-divider"></div>
            </div>
            <div class="about-grid">
                <div class="about-text reveal">
                    <p>I am a developer and designer with over X years of experience in building high-quality digital products.</p>
                    <div class="about-info">
                        <div class="info-item"><div class="label">Email</div><div class="value">sbmousavi@proton.me</div></div>
                        <div class="info-item"><div class="label">Location</div><div class="value">Tehran, Iran</div></div>
                    </div>
                </div>
                <div class="stats reveal">
                    <div class="stat-card"><div class="stat-number">+5</div><div class="stat-label">Years Experience</div></div>
                    <div class="stat-card"><div class="stat-number">+20</div><div class="stat-label">Successful Projects</div></div>
                </div>
            </div>
        </div>
    </section>

    <!-- Custom Services Section -->
    <section id="custom-services">
        <div class="container">
            <div class="services-section reveal">
                <h2 class="section-title">Elevate Your <span>Digital Presence</span></h2>
                <p style="color: #ccc; max-width: 700px; margin: auto; font-size: 1.1rem;">
                    Looking for a unique website that stands out? I offer professional custom design and advanced SEO services tailored to your brand's needs.
                </p>
                <div class="service-list">
                    <div class="service-item"><i class="fas fa-check-circle" style="color: var(--accent);"></i> Custom Web Design</div>
                    <div class="service-item"><i class="fas fa-check-circle" style="color: var(--accent);"></i> Advanced SEO Optimization</div>
                </div>
                <a href="mailto:sbmousavi@proton.me" class="btn btn-primary" style="margin-top: 1rem;">
                    <i class="fas fa-envelope"></i> Contact Behzad Mousavi
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>© <?php echo date('Y'); ?> <?php bloginfo('name'); ?> | Designed with <span class="heart"><i class="fas fa-heart"></i></span> and Code</p>
    </footer>

    <?php wp_footer(); ?>
    
    <!-- JavaScript for Menu and Animations -->
    <script>
        document.querySelector('.menu-toggle').addEventListener('click', () => {
            document.querySelector('.nav-links').classList.toggle('active');
        });
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) entry.target.classList.add('active');
            });
        }, { threshold: 0.1 });
        
        document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    </script>
</body>
</html>